# Overview

The Stretch URDF package provides URDF and Mesh files for use by Stretch Body. 
These are installed and managed completely seperately from the Stretch ROS(2) URDF data.
This package can be installed by:

```
python3 -m pip install  -U hello-robot-stretch-urdf
```

